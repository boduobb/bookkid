/**
 * 腾讯云OCR识别模块
 * 支持通用印刷体识别
 */

// 腾讯云密钥（从环境变量读取）
const TENCENT_SECRET_ID = process.env.TENCENT_SECRET_ID || 'AKIDAJI7nGj7XtGeuysZ5QaYLxYyBF7oaSSm';
const TENCENT_SECRET_KEY = process.env.TENCENT_SECRET_KEY || 'MdpzymHex89zqY7YotqgR4a0RkDnOrR1';
const REGION = 'ap-guangzhou'; // 广州区域

/**
 * 使用腾讯云OCR识别图片文字
 * @param {string} imagePath - 图片文件路径
 * @returns {Promise<string>} 识别出的文字内容
 */
async function recognizeText(imagePath) {
  const fs = require('fs');
  const https = require('https');
  const crypto = require('crypto');
  const { HmacSha1 } = crypto;

  // 读取图片文件
  const imageBuffer = fs.readFileSync(imagePath);
  const imageBase64 = imageBuffer.toString('base64');

  // 生成签名
  const timestamp = Math.floor(Date.now() / 1000);
  const nonce = Math.floor(Math.random() * 1000000);

  // 构建签名原文
  const signatureMethod = 'HmacSHA1';
  const stringToSign = `POSTocr.api.qcloud.com/v2/index.php?Action=GeneralBasicOCR&Nonce=${nonce}&Region=${REGION}&SecretId=${TENCENT_SECRET_ID}&Timestamp=${timestamp}`;

  // 计算签名
  const hmac = HmacSha1.create();
  hmac.update(stringToSign);
  const signature = Buffer.from(hmac.digest('hex')).toString('base64');

  // 构建请求体
  const requestBody = JSON.stringify({
    ImageBase64: imageBase64
  });

  // 构建请求头
  const headers = {
    'Content-Type': 'application/json',
    'Host': 'ocr.api.qcloud.com',
    'X-TC-Action': 'GeneralBasicOCR',
    'X-TC-Version': '2018-11-19',
    'X-TC-Timestamp': timestamp.toString(),
    'X-TC-Nonce': nonce.toString(),
    'X-TC-Region': REGION,
    'X-TC-SecretId': TENCENT_SECRET_ID,
    'X-TC-Signature': signature,
    'X-TC-SignatureMethod': signatureMethod
  };

  // 发送请求
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'ocr.api.qcloud.com',
      port: 443,
      path: '/v2/index.php',
      method: 'POST',
      headers: headers
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          if (result.Response && result.Response.TextDetections) {
            // 提取所有识别出的文字
            const textArray = result.Response.TextDetections
              .filter(item => item.DetectedText)
              .map(item => item.DetectedText);
            
            const fullText = textArray.join('\n');
            console.log(`OCR识别成功，识别文字数: ${textArray.length}`);
            resolve(fullText);
          } else if (result.Response && result.Response.Error) {
            console.error('OCR识别失败:', result.Response.Error);
            reject(new Error(result.Response.Error.Message || 'OCR识别失败'));
          } else {
            console.error('OCR返回格式错误:', data);
            reject(new Error('OCR返回格式错误'));
          }
        } catch (err) {
          console.error('解析OCR结果失败:', err);
          reject(err);
        }
      });
    });

    req.on('error', (err) => {
      console.error('OCR请求失败:', err);
      reject(err);
    });

    req.write(requestBody);
    req.end();
  });
}

/**
 * 批量识别多张图片
 * @param {Array<string>} imagePaths - 图片文件路径数组
 * @returns {Promise<string>} 合并后的识别文字
 */
async function recognizeMultipleImages(imagePaths) {
  const results = [];
  
  for (const imagePath of imagePaths) {
    try {
      const text = await recognizeText(imagePath);
      if (text) {
        results.push(text);
      }
    } catch (err) {
      console.error(`识别图片失败: ${imagePath}`, err);
    }
  }
  
  return results.join('\n\n===== 分割线 =====\n\n');
}

/**
 * 根据识别内容智能判断书籍信息
 * @param {string} text - 识别的文字内容
 * @returns {Object} 书籍信息
 */
function analyzeBookContent(text) {
  // 简单的书籍分析逻辑
  // 实际生产中可以使用AI来更准确地分析
  
  const lines = text.split('\n').filter(l => l.trim());
  const title = lines[0] || '未识别的书籍';
  const author = lines.find(l => l.includes('著') || l.includes('作者')) || '';
  
  // 检测是否为绘本（通常图片多、文字少）
  const isPictureBook = text.length < 500;
  
  // 检测故事角色
  const characters = extractCharacters(text);
  
  // 生成摘要（取前200字）
  const summary = text.substring(0, 200) + (text.length > 200 ? '...' : '');
  
  return {
    title: title.replace(/[著作者:：]/g, '').trim(),
    author: author.replace(/[著作者:：]/g, '').trim(),
    category: isPictureBook ? '绘本故事' : '儿童文学',
    content: text,
    characters,
    summary,
    isPictureBook
  };
}

/**
 * 提取故事中的角色
 * @param {string} text - 识别文字
 * @returns {Array<string>} 角色列表
 */
function extractCharacters(text) {
  // 常见角色称呼
  const commonNames = [
    '小兔子', '大兔子', '小熊', '大熊', '小猪', '猪妈妈', 
    '爷爷', '奶奶', '爸爸', '妈妈', '小明', '小红',
    '小猫', '小狗', '小鸟', '小猴子', '狐狸', '狼',
    '大卫', '约瑟', '爷爷', '奶奶', '小猴子', '小象'
  ];
  
  const found = commonNames.filter(name => text.includes(name));
  
  // 如果没找到，返回默认
  return found.length > 0 ? [...new Set(found)] : ['故事中的角色'];
}

module.exports = {
  recognizeText,
  recognizeMultipleImages,
  analyzeBookContent
};
