// miniprogram/utils/api.js - 后端API请求模块

// 后端服务地址（正式环境 - HTTPS）
// 域名：bookkid.cloud
const API_BASE_URL = 'https://bookkid.cloud';

// ===== 开发环境配置（取消注释使用）=====
// const API_BASE_URL = 'http://localhost:3000';
// const API_BASE_URL = 'http://192.168.1.100:3000'; // 局域网IP（真机调试）

/**
 * 发送HTTP请求
 */
function request(url, method = 'GET', data = {}) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: API_BASE_URL + url,
      method,
      data,
      header: {
        'content-type': 'application/json'
      },
      success: (res) => {
        if (res.data.success) {
          resolve(res.data.data);
        } else {
          reject(new Error(res.data.message || '请求失败'));
        }
      },
      fail: (err) => {
        reject(new Error('网络请求失败: ' + err.errMsg));
      }
    });
  });
}

/**
 * 获取书籍列表
 */
function getBooks() {
  return request('/api/books');
}

/**
 * 获取书籍详情
 */
function getBook(bookId) {
  return request('/api/books/' + bookId);
}

/**
 * 开始阅读对话
 */
function startReading(bookId) {
  return request('/api/chat/start', 'POST', { bookId });
}

/**
 * 发送对话消息
 */
function sendMessage(bookId, userMessage, history = [], phase = 'retelling') {
  return request('/api/chat/message', 'POST', {
    bookId,
    userMessage,
    history,
    phase
  });
}

/**
 * 生成理解题目
 */
function generateQuiz(bookId) {
  return request('/api/quiz/generate', 'POST', { bookId });
}

/**
 * 开始角色扮演
 */
function startRoleplay(bookId, character) {
  return request('/api/roleplay/start', 'POST', { bookId, character });
}

/**
 * 角色扮演对话
 */
function roleplayMessage(bookId, character, userMessage, history = []) {
  return request('/api/roleplay/message', 'POST', {
    bookId,
    character,
    userMessage,
    history
  });
}

/**
 * 获取故事总结反馈
 */
function getSummary(bookId, userSummary) {
  return request('/api/summary', 'POST', { bookId, userSummary });
}

/**
 * 检查服务状态
 */
function checkHealth() {
  return request('/api/health');
}

module.exports = {
  API_BASE_URL,
  request,
  getBooks,
  getBook,
  startReading,
  sendMessage,
  generateQuiz,
  startRoleplay,
  roleplayMessage,
  getSummary,
  checkHealth
};