#!/bin/bash
# deploy.sh - 小书童后端服务部署脚本
# 使用方法: bash deploy.sh

echo "=============================================="
echo "🦉 小书童AI阅读服务部署脚本"
echo "=============================================="

# 1. 检查Node.js
echo ""
echo "[1/6] 检查Node.js环境..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js未安装，请先安装Node.js"
    echo "   下载地址: https://nodejs.cn/download/"
    exit 1
fi
echo "✅ Node.js版本: $(node -v)"

# 2. 检查npm
echo ""
echo "[2/6] 检查npm..."
if ! command -v npm &> /dev/null; then
    echo "❌ npm未安装"
    exit 1
fi
echo "✅ npm版本: $(npm -v)"

# 3. 安装依赖
echo ""
echo "[3/6] 安装项目依赖..."
npm install --production
if [ $? -ne 0 ]; then
    echo "❌ 依赖安装失败"
    exit 1
fi
echo "✅ 依赖安装成功"

# 4. 安装PM2
echo ""
echo "[4/6] 安装PM2进程管理器..."
npm install -g pm2
if [ $? -ne 0 ]; then
    echo "❌ PM2安装失败"
    exit 1
fi
echo "✅ PM2安装成功"

# 5. 创建日志目录
echo ""
echo "[5/6] 创建日志目录..."
mkdir -p logs
echo "✅ 日志目录创建成功"

# 6. 启动服务
echo ""
echo "[6/6] 启动后端服务..."
pm2 start ecosystem.config.js
pm2 save
pm2 startup

echo ""
echo "=============================================="
echo "🎉 部署完成！"
echo "=============================================="
echo ""
echo "服务状态: pm2 status"
echo "查看日志: pm2 logs"
echo "重启服务: pm2 restart xiaoshutong-server"
echo "停止服务: pm2 stop xiaoshutong-server"
echo ""
echo "请确保："
echo "  1. 已配置Nginx反向代理"
echo "  2. 已配置SSL证书(HTTPS)"
echo "  3. 域名已解析到服务器IP"
echo "  4. 小程序后台已添加request合法域名"